public class Test{

    public static void main(String[] args){
            String start = "This_is_a_test";
            StringBuffer sb = new StringBuffer();
            for (String s : start.split("_")) {
                sb.append(Character.toUpperCase(s.charAt(0)));
                if (s.length() > 1) {
                    sb.append(s.substring(1).toLowerCase());
                }
            }
            System.out.println(sb);
        }
        /*String s1= "racecarkayakanna";
                //==> "racecar","kayak","anna"
        String split[] = s1.split("");
        String reverseString = "";
        for(String s2:split){
            StringBuffer sb = new StringBuffer(s2);
            sb.reverse();
            reverseString = reverseString+sb.toString()+"";
        }
        System.out.println(reverseString);
        *//*String s2= "";
        for(int i = s1.length()-1;i>=0;i--){
            char c = s1.charAt(i);
            s2=s2 + c;
        }
        System.out.println(s2);
        if(s1.toLowerCase().equals(s2)){
            System.out.println("String==" +s2+ " is palindrome");
        }else
            System.out.println("String==" +s2+ " is not palindrome");*/

}
