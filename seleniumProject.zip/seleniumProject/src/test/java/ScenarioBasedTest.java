import com.assembly.pages.IntegrationsPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import com.assembly.pages.PricingPage;
import com.assembly.pages.WorkflowPage;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class ScenarioBasedTest {

    WebDriver driver = null;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/Users/kamini.acharya/Documents/chromedriver");
        driver = new ChromeDriver();
    }

    @Test(priority = 1)
    public void testToPrintIntegrations() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();
        driver.get("https://www.joinassembly.com/");
        IntegrationsPage.clickOnIntegration(driver).click();
        driver.manage().window().maximize();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,350)", "");
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        IntegrationsPage.getListOfSSO(driver).get(1).click();
        Thread.sleep(1000);
        softAssert.assertEquals(IntegrationsPage.getListOfIntegrationsInSSO(driver).size(),33);
        IntegrationsPage.clickOnFirstCategory(driver).click();
        String firstText = IntegrationsPage.getText(driver).getText();
        System.out.println("first integration == "+firstText);
        driver.navigate().back();
        IntegrationsPage.clickOnSecondCategory(driver).click();
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        String secondIntegration = IntegrationsPage.getText(driver).getText();
        System.out.println("second integration == "+secondIntegration);
        driver.close();
        softAssert.assertAll();
    }

    @Test(priority = 2)
    public void testToDifferentPricingSection(){
        SoftAssert softAssert = new SoftAssert();
        driver.get("https://www.joinassembly.com/");
        PricingPage.clickOnPricing(driver).click();
        driver.manage().window().maximize();
        List<WebElement> listOfPricing = PricingPage.getListOfPricing(driver);
        softAssert.assertEquals(PricingPage.getListOfPricing(driver).size(),4);
        for (int i = 0; i <= listOfPricing.size()-1; i++) {
            String categoryName = listOfPricing.get(i).getText();
            System.out.println("pricing category name == " + categoryName);
        }
        String starterBillingPrice = PricingPage.getFirstBillingPrice(driver).getText();
        System.out.println("starter Billing Price =="+starterBillingPrice);
        String liteBillingPrice = PricingPage.getSecondBillingPrice(driver).getText();
        System.out.println("lite Billing Price =="+liteBillingPrice);
        String standardBillingPrice = PricingPage.getThirdBillingPrice(driver).getText();
        System.out.println("standard Billing Price =="+ standardBillingPrice);
        String premiumBillingPrice = PricingPage.getFourthBillingPrice(driver).getText();
        System.out.println("premium Billing Price =="+premiumBillingPrice);
        driver.close();
        softAssert.assertAll();

    }

    @Test(priority = 3)
    public void testToVerifyListInWorkflow() {
        SoftAssert softAssert = new SoftAssert();
        driver.get("https://www.joinassembly.com/");
        WorkflowPage.clickOnWorkflow(driver).click();
        driver.manage().window().maximize();
        // Scroll down till webElement
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,350)", "");
        List<WebElement> elements = WorkflowPage.getListOfAllCategory(driver);
        softAssert.assertEquals(elements.size(),8);
        if(elements.size()>1) {
            for (int i = 0; i <= elements.size()-1; i++) {
                String categoryName = elements.get(i).getText();
                System.out.println("category name == " + categoryName);
            }
        }
        WorkflowPage.clickOfExpectedElement(driver).click();
        List<WebElement> featuredCategoryContentList = WorkflowPage.getListOfExpectedContents(driver);
        for (int i = 0; i <= featuredCategoryContentList.size()-1; i++) {
            String featuredContent = featuredCategoryContentList.get(i).getText();
            System.out.println("featured Content name == " + featuredContent);
        }
        driver.close();
        softAssert.assertAll();
    }

    @AfterMethod
    public void tearDown(){
        driver.quit();
    }

}
