package com.assembly.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class WorkflowPage {

    static WebElement element = null;
    static List<WebElement> webElementList = null;

    public static WebElement clickOnWorkflow(WebDriver driver){
        element =driver.findElement(By.xpath("//a[text()='Workflows']"));
        return element;
    }

    public static List<WebElement> getListOfAllCategory(WebDriver driver){
        webElementList =  driver.findElements(By.xpath("//div[@class='template-categories-wrapper']/div[1]/div[1]/div[@role='listitem']"));;
        return webElementList;
    }

    public static WebElement clickOfExpectedElement(WebDriver driver){
        element = driver.findElement(By.xpath("//div[text()='Featured']"));
        return element;
    }

    public static List<WebElement> getListOfExpectedContents(WebDriver driver){
        webElementList = driver.findElements(By.xpath("//div[@class='integrations-wrapper']/div[2]/div/div/div[@role='listitem']"));
        return webElementList;
    }
}
