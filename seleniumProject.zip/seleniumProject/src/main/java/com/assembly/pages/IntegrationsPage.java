package com.assembly.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class IntegrationsPage {

    static WebElement element = null;
    static List<WebElement> webElementList = null;

    public static WebElement clickOnIntegration(WebDriver driver){
        element =driver.findElement(By.xpath("//nav/div/a[4][text()='Integrations']"));
        return element;
    }

    public static List<WebElement> getListOfSSO(WebDriver driver){
       webElementList =  driver.findElements(By.xpath("//div[text()='SSO & HRIS Sync']"));;
        return webElementList;
    }

    public static List<WebElement> getListOfIntegrationsInSSO(WebDriver driver){
        webElementList =  driver.findElements(By.xpath("//div[2][@class='integrations-wrapper']/div[2]/div/div/div[@role='listitem']"));;
        return webElementList;
    }

    public static WebElement clickOnFirstCategory(WebDriver driver){
        element = driver.findElement(By.xpath("//h3[text()='Namely']"));
        return element;
    }

    public static WebElement getText(WebDriver driver){
        element = driver.findElement(By.xpath("//h1[@class='title integration-hero']"));
        return element;
    }

    public static WebElement clickOnSecondCategory(WebDriver driver){
        element = driver.findElement(By.xpath("//h3[text()='Azure SSO']"));
        return element;
    }
}
