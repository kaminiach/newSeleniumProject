package com.assembly.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;


public class PricingPage {

    static WebElement element = null;
    static List<WebElement> webElementList = null;

    public static WebElement clickOnPricing(WebDriver driver){
        element = driver.findElement(By.xpath("//a[text()='Pricing']"));
        return element;
    }

    public static List<WebElement> getListOfPricing(WebDriver driver){
        webElementList = driver.findElements(By.xpath("//div[@class='pricing-table-header bg-white']/div[2]/div"));
        return webElementList;
    }
    //div[@class='pricing-table-header bg-white']/div[2]/div
    public static WebElement getFirstPricingSection(WebDriver driver){
        element =  driver.findElement(By.id("w-node-_20d4cb84-ea7f-d727-562a-140a1d2ba677-7a0d1401"));;
        return element;
    }

    public static WebElement getFirstBillingPrice(WebDriver driver){
        element =  driver.findElement(By.id("w-node-_1b9f726a-c25b-18ed-dd43-f07475e29e87-7a0d1401"));;
        return element;
    }


    public static WebElement getSecondPricingSection(WebDriver driver){
        element = driver.findElement(By.id("w-node-_20d4cb84-ea7f-d727-562a-140a1d2ba679-7a0d1401"));
        return element;
    }

    public static WebElement getSecondBillingPrice(WebDriver driver){
        element = driver.findElement(By.id("w-node-_1b9f726a-c25b-18ed-dd43-f07475e29e89-7a0d1401"));
        return element;
    }

    public static WebElement getThirdPricingSection(WebDriver driver){
        element = driver.findElement(By.xpath("//h5[@class='no-bottom-space-2-primary']"));
        return element;
    }

    public static WebElement getThirdBillingPrice(WebDriver driver){
        element = driver.findElement(By.id("w-node-_1b9f726a-c25b-18ed-dd43-f07475e29e8b-7a0d1401"));
        return element;
    }

    public static WebElement getFourthPricingSection(WebDriver driver){
        element = driver.findElement(By.id("w-node-_20d4cb84-ea7f-d727-562a-140a1d2ba67d-7a0d1401"));
        return element;
    }

    public static WebElement getFourthBillingPrice(WebDriver driver){
        element = driver.findElement(By.id("w-node-_1b9f726a-c25b-18ed-dd43-f07475e29e8d-7a0d1401"));
        return element;
    }
}
