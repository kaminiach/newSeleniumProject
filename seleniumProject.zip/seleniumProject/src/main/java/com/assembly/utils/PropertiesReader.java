package com.assembly.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesReader {


    static Properties properties;

    public PropertiesReader(){
        loadAllProperties();

    }

    public void loadAllProperties(){
        try {
            String fileName = System.getProperty("user.dir")+"/src/main/resources/prod_config.properties";
            properties.load(new FileInputStream(fileName));
        }catch (IOException e){
            throw new RuntimeException("not able to find the file");

        }
    }

    public static String readItem(String propertyName){
        return properties.getProperty(propertyName);
    }
}
